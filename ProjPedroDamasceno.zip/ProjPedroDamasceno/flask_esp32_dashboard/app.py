# app.py
from flask import Flask, render_template, request, jsonify
import requests
import threading
import time
from datetime import datetime

app = Flask(__name__)

# --- Configuração ---
ESP32_URL = None
UPDATE_INTERVAL = 10
dados_atuais = {"analog": 0, "tensao": 0.0, "escala": 0, "estado": 0, "timestamp": "--:--:--"}
historico_tensao = []
conectado = False
thread = None

# --- Cores dos LEDs por estado ---
LED_CORES = {
    0: "#95a5a6",  # cinza (desligado)
    1: "#27ae60",  # verde
    2: "#f39c12",  # amarelo
    3: "#3498db",  # azul
    4: "#9b59b6",  # roxo
    5: "#e74c3c"   # vermelho
}

# --- Atualização em segundo plano ---
def atualizar_dados():
    global conectado, dados_atuais, historico_tensao
    while conectado:
        if not ESP32_URL:
            time.sleep(1)
            continue
        try:
            response = requests.get(ESP32_URL, timeout=5)
            if response.status_code == 200:
                json_data = response.json()
                dados_atuais.update({
                    "analog": json_data.get("analog", 0),
                    "tensao": json_data.get("tensao", 0.0),
                    "escala": json_data.get("escala", 0),
                    "estado": json_data.get("estado", 0),
                    "timestamp": datetime.now().strftime("%H:%M:%S")
                })
                historico_tensao.append({"x": dados_atuais["timestamp"], "y": dados_atuais["tensao"]})
                if len(historico_tensao) > 50:
                    historico_tensao.pop(0)
        except:
            dados_atuais["timestamp"] = "Erro"
        time.sleep(UPDATE_INTERVAL)

# --- Rota principal ---
@app.route('/', methods=['GET', 'POST'])
def index():
    global ESP32_URL, conectado, thread
    if request.method == 'POST':
        ip = request.form.get('ip', '').strip()
        if ip:
            ESP32_URL = f"http://{ip}/data"
            conectado = True
            if thread is None or not thread.is_alive():
                thread = threading.Thread(target=atualizar_dados, daemon=True)
                thread.start()
            return render_template('dashboard.html')
        else:
            return render_template('index.html', erro="Digite um IP válido!")
    return render_template('index.html')

# --- API com LED colorido ---
@app.route('/api/dados')
def api_dados():
    estado = dados_atuais["estado"]
    return jsonify({
        "atual": dados_atuais,
        "historico": historico_tensao[-20:],
        "led_cor": LED_CORES.get(estado, "#95a5a6"),
        "led_status": "DESLIGADO" if estado == 0 else f"ATIVO (LED {estado})"
    })

if __name__ == '__main__':
    print("Dashboard: http://localhost:5000")
    app.run(host='0.0.0.0', port=5000, debug=False)