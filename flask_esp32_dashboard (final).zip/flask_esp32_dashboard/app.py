# app.py
from flask import Flask, render_template, request, jsonify
import requests
import threading
import time
from datetime import datetime

app = Flask(__name__)

# --- VARIÁVEIS GLOBAIS ---
ESP32_URL = None
UPDATE_INTERVAL = 1  # 1 segundo
dados_atuais = {"analog": 0, "tensao": 0.0, "escala": 0, "estado": 0, "timestamp": "00:00:00"}
historico_tensao = []
conectado = False
thread = None
lock = threading.Lock()

# --- 10 CORES VIBRANTES ---
LED_CORES = {
    0: {"base": "#7f8c8d", "glow": "#95a5a6", "nome": "DESLIGADO"},
    1: {"base": "#2ecc71", "glow": "#27ae60", "nome": "VERDE"},
    2: {"base": "#f1c40f", "glow": "#f39c12", "nome": "AMARELO"},
    3: {"base": "#3498db", "glow": "#2980b9", "nome": "AZUL"},
    4: {"base": "#9b59b6", "glow": "#8e44ad", "nome": "ROXO"},
    5: {"base": "#e74c3c", "glow": "#c0392b", "nome": "VERMELHO"},
    6: {"base": "#1abc9c", "glow": "#16a085", "nome": "CIANO"},
    7: {"base": "#e67e22", "glow": "#d35400", "nome": "LARANJA"},
    8: {"base": "#e91e63", "glow": "#c2185b", "nome": "ROSA"},
    9: {"base": "#ecf0f1", "glow": "#bdc3c7", "nome": "BRANCO"}
}

# --- FUNÇÃO DE ATUALIZAÇÃO (THREAD SEGURA) ---
def atualizar_dados():
    global dados_atuais, historico_tensao, conectado
    while True:
        if not conectado or not ESP32_URL:
            time.sleep(1)
            continue
        try:
            response = requests.get(ESP32_URL, timeout=3)
            if response.status_code == 200:
                json_data = response.json()
                with lock:
                    dados_atuais.update({
                        "analog": json_data.get("analog", 0),
                        "tensao": round(float(json_data.get("tensao", 0)), 2),
                        "escala": json_data.get("escala", 0),
                        "estado": min(max(int(json_data.get("estado", 0)), 0), 9),
                        "timestamp": datetime.now().strftime("%H:%M:%S")
                    })
                    historico_tensao.append({
                        "x": dados_atuais["timestamp"],
                        "y": dados_atuais["tensao"]
                    })
                    if len(historico_tensao) > 60:
                        historico_tensao.pop(0)
        except Exception as e:
            print(f"[ERRO] {e}")
            with lock:
                dados_atuais["timestamp"] = "ERRO"
        time.sleep(UPDATE_INTERVAL)

# --- ROTA INICIAL ---
@app.route('/', methods=['GET', 'POST'])
def index():
    global ESP32_URL, conectado, thread
    if request.method == 'POST':
        ip = request.form.get('ip', '').strip()
        if ip and len(ip.split('.')) == 4 and all(p.isdigit() for p in ip.split('.')):
            ESP32_URL = f"http://{ip}/data"
            conectado = True
            if thread is None or not thread.is_alive():
                thread = threading.Thread(target=atualizar_dados, daemon=True)
                thread.start()
            return render_template('dashboard.html')
        else:
            return render_template('index.html', erro="IP inválido!")
    return render_template('index.html')

# --- API DE DADOS ---
@app.route('/api/dados')
def api_dados():
    with lock:
        estado = dados_atuais["estado"]
        cor = LED_CORES.get(estado, LED_CORES[0])
        return jsonify({
            "atual": dados_atuais.copy(),
            "historico": historico_tensao[-30:],
            "led": {
                "cor_base": cor["base"],
                "cor_glow": cor["glow"],
                "ativo": estado != 0,
                "label": cor["nome"] if estado == 0 else f"{cor['nome']} (LED {estado})"
            }
        })

if __name__ == '__main__':
    print("DASHBOARD FUNCIONANDO: http://localhost:5000")
    print("ATUALIZAÇÃO: A CADA 1 SEGUNDO")
    app.run(host='0.0.0.0', port=5000, debug=False, threaded=True)