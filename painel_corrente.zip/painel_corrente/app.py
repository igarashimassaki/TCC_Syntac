from flask import Flask, render_template, jsonify
import requests
import time
from datetime import datetime
from threading import Thread
import logging
import json

# Configurações
ESP32_IP = "10.83.162.116"  # <-- 🔧 ALTERE PARA O IP DO SEU ESP32!
ESP32_URL = f"http://{ESP32_IP}/"
UPDATE_INTERVAL = 60  # segundos

# Estado compartilhado
current_current = 0.0
history = []
max_history_points = 100

app = Flask(__name__)
logging.getLogger("urllib3").setLevel(logging.WARNING)

def fetch_current():
    global current_current, history
    while True:
        try:
            response = requests.get(ESP32_URL, timeout=10)
            response.encoding = 'utf-8'
            raw_text = response.text.strip()

            if not raw_text:
                raise ValueError("Resposta vazia do ESP32")

            # Parse manual com validação estrita
            data = json.loads(raw_text)

            # Verifica se é uma lista com pelo menos um objeto contendo "Corrente"
            if isinstance(data, list) and len(data) > 0:
                item = data[0]
                if isinstance(item, dict) and "Corrente" in item:
                    current_current = float(item["Corrente"])
                    timestamp = datetime.now().strftime("%H:%M:%S")
                    history.append({"timestamp": timestamp, "value": current_current})
                    if len(history) > max_history_points:
                        history.pop(0)
                    print(f"[{timestamp}] Corrente: {current_current:.3f} A")
                else:
                    print("⚠️ Erro: objeto não contém chave 'Corrente'")
                    current_current = -1
            else:
                print("⚠️ Erro: resposta não é uma lista ou está vazia")
                current_current = -1

        except json.JSONDecodeError as e:
            print(f"⚠️ Erro ao decodificar JSON: {e} | Texto recebido: '{raw_text}'")
            current_current = -1
        except Exception as e:
            print(f"⚠️ Erro de comunicação com ESP32: {e}")
            current_current = -1

        time.sleep(UPDATE_INTERVAL)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/current')
def api_current():
    return jsonify({
        "current": current_current,
        "history": history.copy()
    })

if __name__ == '__main__':
    Thread(target=fetch_current, daemon=True).start()
    print("Painel de corrente iniciado.")
    print(f"Acesse: http://localhost:5000")
    print(f"Buscando dados em: {ESP32_URL}")
    app.run(host='0.0.0.0', port=5000, debug=True, use_reloader=False)